# AGD-4-Hive
Curso sobre Apache Hive (https://hive.apache.org)
